from lifestore_file import lifestore_products, lifestore_sales, lifestore_searches

#Título de bienvenida al programa.
bienvenida = "Bienvenido a LifeStore\n"

print(bienvenida.center(50))

#Usuarios registrados.
lista_administradores = [["alejandro","3997"],["javier","123"]]

#Ingreso de los usuarios
usuario = input("Ingresa tu nombre de usuario: \n")
contraseña = input("Ingresa tu contraseña: \n")

es_admin = 0 #si es 1, es admin. Si es 0, no es admin
intentos = 3 #número de intentos para iniciar sesión

while es_admin !=1 and intentos !=0:
  for admin in lista_administradores:
    if admin[0] == usuario and admin[1] == contraseña:
      es_admin = 1

#En caso de que haya colocado los datos de inicio de sesión incorrecto
  if es_admin == 0:
      print("Datos incorrectos")
      print("Intentos restantes:",intentos)
      usuario = input("Ingresa tu nombre de usuario: ")
      contraseña = input("Ingresa tu contraseña: ")
      intentos -= 1

#En caso de que haya colocado los datos de inicio de sesión correctamente
  if es_admin == 1:
    print("Bienvenido al sistema de LifeStore\n".center(50))
    print("¿En que lo puedo ayudar?\n")
    print("(A) LOS PRODUCTOS MAS VENDIDOS\n\n(B) LOS PRODUCTOS MAYOR BUSCADOS\n\n(C) LOS PRODUCTOS CON MENORES VENTAS\n\n(D) LOS PRODUCTOS CON MENORES BÚSQUEDAS\n\n(E) LOS PRODUCTOS CON MEJORES RESEÑAS\n\n(F) LOS PRODUCTOS CON PEORES RESEÑAS\n\n")
    Escoger_una_opción = input("Escriba la opción: \n")

    #Opción <Productos mas vendidos>
    if Escoger_una_opción == "A":
      contador = 0
      ventas_producto = [] #[ID PRODUCT,NOMBRE DEL PRODUCTO, PRECIO, CATEGORÍA, STOCK, NUM DE VENTAS]
      for producto in lifestore_products:
        for venta in lifestore_sales:
          if producto[0] == venta[1]:
            contador += 1
        if contador != 0:
           ventas_producto.append([producto[0],producto[1],producto[2],producto[3],producto[4],contador])
           contador = 0   

      #Ordenar la lista de mayor a menor
      productos_ordenados = []
      
      #Título de cada columna
      print("LOS 20 PRODUCTOS MAS VENDIDOS\n") #Título de la sección
      print("{:<3}".format("NO."),"{:<6}".format("ID PR"),"{:<15}".format("NOMBRE DEL PROD"),"{:<8}".format("PRECIO"),"{:<12}".format("CATEGORÍA"),"{:<6}".format("BUSQ"),"{:<8}".format("NO. VENT"),"{:<10}".format("INGRESO\n")) 

      while ventas_producto:
        maximo = ventas_producto [0][5]
        lista_max = ventas_producto[0]
        for totalventa in ventas_producto:
         if totalventa[5] > maximo:
            maximo = totalventa[5]
            lista_max = totalventa
        productos_ordenados.append(lista_max)
        ventas_producto.remove(lista_max)
        
        número_lista = 0 #Para agregar númeración a la lista

        for items in productos_ordenados:
            número_lista +=1
        
            ingresos_totales = items[2] * items[5]
            if número_lista == 31:
               break
          #Para sacar el ingreso total de cada producto
         
        
        print("{:<3}".format(número_lista),"{:<6}".format(items[0]),"{:<15}".format(items[1][0:14]),"$", "{:<6}".format(items[2]),"{:<12}".format(items[3][0:10]),"{:<6}".format(items[4]),"{:<8}".format(items[5]),"$","{:<20}".format(ingresos_totales))

        
      
      número_lista = 0 #Para agregar númeración a la lista
    #Opción <Productos mas buscados>
    if Escoger_una_opción == "B":
      búsquedas = 0
      búsquedas_producto = [] #[ID PRODUCT,NOMBRE DEL PRODUCTO, NO. DE BÚSQUEDAS]
      for producto in lifestore_products:
        for search in lifestore_searches:
          if producto[0] == search[1]:
            búsquedas += 1
        if búsquedas != 0:
          búsquedas_producto.append([producto[0],producto[1],búsquedas])
          búsquedas = 0
      productos_ordenados_b = []

      print("LOS 20 PRODUCTOS MAS BUSCADOS\n") #Título de la sección
      print("{:<3}".format("NO."),"{:<3}".format("ID"),"{:<16}".format("NOMBRE DEL PROD"),"{:<6}".format("BUSQ")) #Título de cada columna
      print("\n")
    

      while búsquedas_producto:
        maximo = búsquedas_producto [0][2]
        lista_max = búsquedas_producto[0]
        for totalbúsqueda in búsquedas_producto:
          if totalbúsqueda[2] > maximo:
            maximo = totalbúsqueda[2]
            lista_max = totalbúsqueda
        productos_ordenados_b.append(lista_max)
        búsquedas_producto.remove(lista_max)
        número_lista_b = 0 #Para agregar númeración a la lista

        for itemsb in productos_ordenados_b:
          número_lista_b +=1
          
        if número_lista_b == 31:
          break
      
        print("{:<3}".format(número_lista_b),"{:<3}".format(itemsb[0]),"{:<16}".format(itemsb[1][0:15]),"{:<3}".format(itemsb[2]))
    #Opción <Productos menos vendidos>
    if Escoger_una_opción == "C":
      contadorm = 0
      ventas_producto_m = [] #[ID PRODUCT,NOMBRE DEL PRODUCTO, PRECIO, CATEGORÍA, STOCK, NUM DE VENTAS]
      for productom in lifestore_products:
        for ventam in lifestore_sales:
          if productom[0] == ventam[1]:
            contadorm += 1
        if contadorm != 0:
           ventas_producto_m.append([productom[0],productom[1],productom[2],productom[3],productom[4],contadorm])
           contadorm = 0   
      #Ordenar la lista de mayor a menor
      productos_ordenados_m = []

      print("LOS 20 PRODUCTOS MENOS VENDIDOS\n") #Título de la sección
      print("{:<3}".format("NO."),"{:<6}".format("ID PR"),"{:<15}".format("NOMBRE DEL PROD"),"{:<8}".format("PRECIO"),"{:<12}".format("CATEGORÍA"),"{:<6}".format("BUSQ"),"{:<8}".format("NO. VENT\n")) #Título de cada columna
      
      while ventas_producto_m:
        minimo = ventas_producto_m [0][5]
        lista_min = ventas_producto_m[0]
        for totalventa_m in ventas_producto_m:
         if totalventa_m[5] < minimo:
            minimo = totalventa_m[5]
            lista_min = totalventa_m
        productos_ordenados_m.append(lista_min)
        ventas_producto_m.remove(lista_min)
        número_lista_m = 0 #Para agregar númeración a la lista

        for itemsm in productos_ordenados_m:
          número_lista_m +=1
          
        if número_lista_m == 31:
          break

        print("{:<3}".format(número_lista_m),"{:<6}".format(itemsm[0]),"{:<15}".format(itemsm[1][0:14]),"$", "{:<6}".format(itemsm[2]),"{:<12}".format(itemsm[3][0:10]),"{:<6}".format(itemsm[4]),"{:<8}".format(itemsm[5]))
  
    #Opción <Productos menos buscados>
    if Escoger_una_opción == "D":
      búsquedasm = 0
      búsquedas_productom = [] #[ID PRODUCT,NOMBRE DEL PRODUCTO, NO. DE BÚSQUEDAS]
      for productom in lifestore_products:
        for searchm in lifestore_searches:
          if productom[0] == searchm[1]:
            búsquedasm += 1
        if búsquedasm != 0:
          búsquedas_productom.append([productom[0],productom[1],búsquedasm])
          búsquedasm = 0
      productos_ordenados_bm = []

      print("LOS 20 PRODUCTOS MENOS BUSCADOS\n") #Título de la sección
      print("{:<3}".format("NO."),"{:<3}".format("ID"),"{:<16}".format("NOMBRE DEL PROD"),"{:<6}".format("BUSQ")) #Título de cada columna
      print("\n")
    
      #Ordenar la lista de mayor a menor
      while búsquedas_productom:
        minimom = búsquedas_productom [0][2]
        lista_minm = búsquedas_productom[0]
        for totalbúsquedam in búsquedas_productom:
          if totalbúsquedam[2] < minimom:
            minimom = totalbúsquedam[2]
            lista_minm = totalbúsquedam
        productos_ordenados_bm.append(lista_minm)
        búsquedas_productom.remove(lista_minm)
        número_lista_bm = 0 #Para agregar númeración a la lista

        for itemsbm in productos_ordenados_bm:
          número_lista_bm +=1
          
        if número_lista_bm == 31:
          break
      
        print("{:<3}".format(número_lista_bm),"{:<3}".format(itemsbm[0]),"{:<16}".format(itemsbm[1][0:15]),"{:<3}".format(itemsbm[2]))
    
    #Opción <Productos mejores reseñas>
    if Escoger_una_opción == "E":
      contador_reseña = 0
      contador_promedio = 0
      reseñas_producto = [] #[ID PRODUCT,NOMBRE DEL PRODUCTO, NUMERO DE RESEÑAS, PROM DE RESEÑAS]
      for producto_r in lifestore_products:
        for venta_r in lifestore_sales:
          if producto_r[0] == venta_r[1]:
            contador_reseña += 1
            contador_promedio += venta_r[2]
            promedio_reseña = (contador_promedio/contador_reseña)
        if contador_reseña != 0:
          reseñas_producto.append([producto_r[0],producto_r[1],contador_reseña,promedio_reseña])
          contador_reseña = 0
          contador_promedio = 0   

      #Ordenar la lista de mayor a menor
      productos_reseña_ordenados = []
      
      print("LOS 20 PRODUCTOS CON MEJORES RESEÑAS\n") #Título de la sección
      print("{:<3}".format("NO."),"{:<3}".format("ID"),"{:<16}".format("NOMBRE DEL PROD"),"{:<12}".format("NO. RESEÑAS"),"{:<12}".format("PROM. RESEÑAS\n")) #Título de cada columna

      while reseñas_producto:
        mejores = reseñas_producto [0][3]
        lista_mej = reseñas_producto[0]
        for totalreseña in reseñas_producto:
          if totalreseña[3] > mejores:
            mejores = totalreseña [3]
            lista_mej = totalreseña
        productos_reseña_ordenados.append(lista_mej)
        reseñas_producto.remove(lista_mej)
        número_lista_res = 0 #Para agregar númeración a la lista

        for itemreseña in productos_reseña_ordenados:
          número_lista_res +=1
                    
          
        if número_lista_res == 21:
          break
        
        print("{:<3}".format(número_lista_res),"{:<3}".format(itemreseña[0]),"{:<16}".format(itemreseña[1][0:15]),"{:<12}".format(itemreseña[2]),"{:<3}".format(itemreseña[3]))
      
      
     #Opción <Productos peores reseñas>
    if Escoger_una_opción == "F":
      contador_reseña_m = 0
      contador_promedio_m = 0
      reseñas_producto_m = [] #[ID PRODUCT,NOMBRE DEL PRODUCTO, NUMERO DE RESEÑAS, PROM DE RESEÑAS]
      for producto_r_m in lifestore_products:
        for venta_r_m in lifestore_sales:
          if producto_r_m[0] == venta_r_m[1]:
            contador_reseña_m += 1
            contador_promedio_m += venta_r_m[2]
            promedio_reseña_m = (contador_promedio_m/contador_reseña_m)
        if contador_reseña_m != 0:
          reseñas_producto_m.append([producto_r_m[0],producto_r_m[1],contador_reseña_m,promedio_reseña_m])
          contador_reseña_m = 0
          contador_promedio_m = 0   

      #Ordenar la lista de mayor a menor
      productos_reseñam_ordenados = []

      print("LOS 20 PRODUCTOS CON PEROES RESEÑAS\n") #Título de la sección
      print("{:<3}".format("NO."),"{:<3}".format("ID"),"{:<16}".format("NOMBRE DEL PROD"),"{:<12}".format("NO. RESEÑAS"),"{:<12}".format("PROM. RESEÑAS\n")) #Título de cada columna

      while reseñas_producto_m:
        peores = reseñas_producto_m [0][3]
        lista_peo = reseñas_producto_m[0]
        for totalreseñam in reseñas_producto_m:
          if totalreseñam[3] < peores:
            peores = totalreseñam [3]
            lista_peo = totalreseñam
        productos_reseñam_ordenados.append(lista_peo)
        reseñas_producto_m.remove(lista_peo)
        número_lista_resm = 0 #Para agregar númeración a la lista

        for itemreseñam in productos_reseñam_ordenados:
          número_lista_resm +=1
                    
          
        if número_lista_resm == 21:
          break
        
        print("{:<3}".format(número_lista_resm),"{:<3}".format(itemreseñam[0]),"{:<16}".format(itemreseñam[1][0:15]),"{:<12}".format(itemreseñam[2]),"{:<3}".format(itemreseñam[3]))
      
       

